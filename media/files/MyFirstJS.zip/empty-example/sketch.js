var api = 'http://api.openweathermap.org/data/2.5/weather?q=';
var api_key = '&APPID=58f3134069214bf7f264db0d5664afda';
var units = '&units=metric';
var city = 'london';
var url;
var weather;
var input;


function setup() {
    createCanvas(400, 200);  
    
    var button = select('#submit');
    button.mousePressed(weatherAsk);
    
    input = select('#city');
}

function weatherAsk(){
    //console.log(input);
    url = api + input.value() + api_key + units;    
    loadJSON(url, gotData);
}

function gotData(data){
    weather = data;
    println(data);
}

function draw() {
   
    background(0);
    if (weather){
        var temp = weather.main.temp;
        var humidity = weather.main.humidity;
        ellipse(100, 100, temp, temp);
        ellipse(300, 100, humidity, humidity);
        console.log(url);
    }

}

