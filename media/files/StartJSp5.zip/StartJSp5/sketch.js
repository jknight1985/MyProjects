var api = 'http://api.openweathermap.org/data/2.5/weather?q=';
var api_key = '&APPID=58f3134069214bf7f264db0d5664afda';
var city = 'London';
var units = '&units=metric';
var url = api + city + api_key + units;
var weather;

function setup() {
    createCanvas(400, 200);
    loadJSON(url, gotData);
}

function gotData(data){
    weather = data;
    println(data);
}

function draw() {
   
    background(0);
    if (weather){
        var temp = weather.main.temp;
        var humidity = weather.main.humidity;
        ellipse(100, 100, temp, temp);
        ellipse(300, 100, humidity, humidity);
        console.log(url);
    }
    /*
    background(0);
    rect(50,50,50,50);
    console.log(url);
    */
}

